import { useState } from 'react'
import './App.css'

import Index from './layout/index'
function App() {

  return (
    <>
      <Index></Index>
    </>
  )
}

export default App
